import monzoAPI
import capitalOneAPI

monzoAPI.do()
capitalOneAPI.do()